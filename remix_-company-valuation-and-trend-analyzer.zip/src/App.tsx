/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Search, 
  X, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle, 
  TrendingDown, 
  Clock, 
  Compass, 
  Target, 
  Activity, 
  DollarSign, 
  RefreshCw, 
  ArrowRight,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { CompanyStock } from "./types";

export default function App() {
  const [stocks, setStocks] = useState<CompanyStock[]>([]);
  const [searchInput, setSearchInput] = useState("");
  const [selectedStock, setSelectedStock] = useState<CompanyStock | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState<string>("");

  // Update clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toUTCString());
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Fetch stocks on mount
  const fetchStocks = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/stocks");
      if (res.ok) {
        const data = await res.json();
        setStocks(data);
      }
    } catch (err) {
      console.error("Failed to load stocks:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStocks();
  }, []);

  // Search and analyze a ticker
  const handleAnalyze = async (tickerToAnalyze?: string) => {
    const targetTicker = (tickerToAnalyze || searchInput).toUpperCase().trim();
    if (!targetTicker) return;

    setIsAnalyzing(true);
    setAnalysisError(null);
    try {
      const res = await fetch("/api/stocks/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticker: targetTicker }),
      });

      if (res.ok) {
        const newStock = await res.json();
        setStocks((prev) => {
          const exists = prev.findIndex((s) => s.ticker === newStock.ticker);
          if (exists !== -1) {
            const next = [...prev];
            next[exists] = newStock;
            return next;
          }
          return [newStock, ...prev];
        });
        setSelectedStock(newStock);
        setSearchInput("");
      } else {
        const errData = await res.json();
        setAnalysisError(errData.error || "Analysis failed. Please try again.");
      }
    } catch (err) {
      console.error("Analysis failed:", err);
      setAnalysisError("Server connection error. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getTrendColor = (tier: string) => {
    if (tier === "Very High") return "text-emerald-600 bg-emerald-50 border-emerald-100";
    if (tier === "High") return "text-blue-600 bg-blue-50 border-blue-100";
    if (tier === "Moderate") return "text-amber-600 bg-amber-50 border-amber-100";
    return "text-slate-500 bg-slate-50 border-slate-100";
  };

  const getTrendArrow = (tier: string) => {
    if (tier === "Very High") return "↑↑ Very High";
    if (tier === "High") return "↑ High";
    if (tier === "Moderate") return "→ Moderate";
    return "↓ Low";
  };

  const getStanceColor = (stance: string) => {
    if (stance === "Strong Buy") return "text-emerald-700 bg-emerald-100/80 border-emerald-200";
    if (stance === "Buy") return "text-blue-700 bg-blue-100/80 border-blue-200";
    if (stance === "Hold") return "text-amber-700 bg-amber-100/80 border-amber-200";
    return "text-rose-700 bg-rose-100/80 border-rose-200";
  };

  const getRiskColor = (risk: string) => {
    if (risk === "Low") return "text-emerald-600 border-emerald-200 bg-emerald-50/50";
    if (risk === "Medium") return "text-blue-600 border-blue-200 bg-blue-50/50";
    if (risk === "High") return "text-amber-600 border-amber-200 bg-amber-50/50";
    return "text-rose-600 border-rose-200 bg-rose-50/50";
  };

  // Helper stats
  const averageScore = stocks.length 
    ? Math.round(stocks.reduce((sum, s) => sum + s.score, 0) / stocks.length) 
    : 0;

  const topPerformer = stocks.length
    ? [...stocks].sort((a, b) => b.score - a.score)[0]
    : null;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-blue-100 selection:text-blue-800" id="main-container">
      {/* Upper Utility Navbar */}
      <div className="bg-slate-900 text-slate-400 py-2 px-4 md:px-8 flex flex-col sm:flex-row justify-between items-center text-xs border-b border-slate-800" id="top-utility-bar">
        <div className="flex items-center gap-2 mb-1 sm:mb-0" id="brand-indicator">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" id="pulse-dot"></span>
          <span className="font-semibold tracking-wider text-slate-200" id="brand-label">3FRONT REAL-TIME ANALYSIS ENGINE</span>
        </div>
        <div className="flex items-center gap-4 font-mono" id="time-indicator">
          <span className="flex items-center gap-1" id="clock-wrapper">
            <Clock className="w-3.5 h-3.5 text-slate-500" id="clock-icon" />
            {currentTime || "Loading UTC time..."}
          </span>
        </div>
      </div>

      {/* Main Header / Banner Hero */}
      <header className="bg-white border-b border-slate-200 py-8 px-4 md:px-8" id="header-container">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-6" id="header-content">
          <div id="title-section">
            <div className="flex items-center gap-2.5 mb-1" id="logo-badge-container">
              <span className="bg-blue-600 text-white font-mono font-black px-2 py-0.5 rounded text-sm" id="logo-badge">3F</span>
              <span className="text-xs uppercase tracking-widest font-mono text-slate-500 font-bold" id="version-label">System Terminal v2.5</span>
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900" id="app-title">
              Upcoming Stocks Under $10 Analyzer
            </h1>
            <p className="text-sm text-slate-500 mt-1 max-w-xl" id="app-description">
              Harness live Google Search Grounding &amp; proprietary models to perform instant, high-fidelity trend diagnostics, structural catalysts tracking, and financial valuation of high-growth companies under $10.
            </p>
          </div>

          {/* Quick Stats Block */}
          <div className="grid grid-cols-3 gap-3 md:gap-6 bg-slate-50 p-4 rounded-xl border border-slate-200" id="quick-stats-block">
            <div className="text-center md:text-left" id="stat-count">
              <span className="block text-xs font-medium text-slate-500 uppercase tracking-wider" id="stat-count-lbl">Tracked</span>
              <span className="text-xl font-extrabold text-slate-800" id="stat-count-val">{stocks.length} Tickers</span>
            </div>
            <div className="text-center md:text-left border-x border-slate-200 px-3 md:px-6" id="stat-avg">
              <span className="block text-xs font-medium text-slate-500 uppercase tracking-wider" id="stat-avg-lbl">Avg Score</span>
              <span className="text-xl font-extrabold text-blue-600" id="stat-avg-val">{averageScore}/100</span>
            </div>
            <div className="text-center md:text-left" id="stat-top">
              <span className="block text-xs font-medium text-slate-500 uppercase tracking-wider" id="stat-top-lbl">Top Index</span>
              <span className="text-xl font-extrabold text-emerald-600" id="stat-top-val">
                {topPerformer ? topPerformer.ticker : "N/A"}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Workspace */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-8" id="main-workspace">
        
        {/* Search and Analyze Interface */}
        <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 mb-8" id="search-section">
          <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2" id="search-section-title">
            <Compass className="w-5 h-5 text-blue-600" id="compass-icon" /> Run Diagnostics on a New Company
          </h2>

          <div className="flex flex-col md:flex-row gap-3" id="search-form-container">
            <div className="relative flex-grow" id="input-relative-container">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none" id="search-icon-wrapper">
                <Search className="h-5 w-5 text-slate-400" id="search-icon" />
              </div>
              <input
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAnalyze()}
                placeholder="Enter sub-$10 growth ticker (e.g. SOFI, IONQ, CLSK, NIO, PLUG, SNDL)..."
                className="block w-full pl-10 pr-4 py-3 bg-slate-50 hover:bg-slate-50/80 focus:bg-white border border-slate-200 focus:border-blue-500 rounded-xl text-slate-900 placeholder-slate-400 font-medium outline-none transition-all focus:ring-4 focus:ring-blue-100"
                id="ticker-search-input"
                disabled={isAnalyzing}
              />
            </div>
            <button
              onClick={() => handleAnalyze()}
              disabled={isAnalyzing || !searchInput.trim()}
              className="px-6 py-3 bg-slate-900 text-white font-semibold rounded-xl hover:bg-slate-800 disabled:bg-slate-200 disabled:text-slate-400 transition-all flex items-center justify-center gap-2 min-w-[140px] focus:ring-4 focus:ring-slate-200 active:scale-95"
              id="analyze-submit-button"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" id="spin-icon" />
                  Analyzing...
                </>
              ) : (
                <>
                  Analyze Ticker
                  <ArrowRight className="w-4 h-4" id="arrow-icon" />
                </>
              )}
            </button>
          </div>

          {/* Quick-select Hot-Tags */}
          <div className="mt-4 flex flex-wrap items-center gap-2" id="hot-tags-container">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider" id="tags-lbl">Interactive Presets:</span>
            {["SOFI", "IONQ", "CLSK", "NIO", "DNA", "PLUG", "HUT", "SNDL"].map((sym) => (
              <button
                key={sym}
                onClick={() => {
                  setSearchInput(sym);
                  handleAnalyze(sym);
                }}
                disabled={isAnalyzing}
                className="px-2.5 py-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-600 rounded text-xs font-mono font-semibold text-slate-600 border border-slate-200 hover:border-blue-200 transition-colors cursor-pointer"
                id={`preset-tag-${sym}`}
              >
                +{sym}
              </button>
            ))}
          </div>

          {/* Error Banner */}
          <AnimatePresence>
            {analysisError && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-4 p-4 bg-rose-50 border border-rose-100 text-rose-700 rounded-xl text-sm flex items-start gap-3"
                id="error-banner"
              >
                <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" id="alert-icon" />
                <div>
                  <span className="font-bold block" id="err-title">Analysis Interrupted</span>
                  <p id="err-desc">{analysisError}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        {/* Dynamic App Warning Banner if no real API key is detected */}
        {process.env.GEMINI_API_KEY === "MY_GEMINI_API_KEY" && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-8 text-sm text-amber-800 flex items-start gap-3" id="demo-mode-alert">
            <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Demo Sandbox Mode</p>
              <p>To power live Google Search Grounding and custom AI analysis, configure your real <strong>GEMINI_API_KEY</strong> in the Secrets panel in Settings. Currently using high-fidelity simulations for search results.</p>
            </div>
          </div>
        )}

        {/* Stock Grid Layout */}
        <section id="companies-grid-section">
          <div className="flex justify-between items-center mb-6" id="grid-header">
            <h3 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2" id="grid-title">
              <Activity className="w-5 h-5 text-emerald-600" id="activity-icon" /> Tracked Financial Indexes
            </h3>
            <button 
              onClick={fetchStocks} 
              className="text-xs font-semibold text-slate-500 hover:text-blue-600 flex items-center gap-1 bg-white px-3 py-1.5 rounded-lg border border-slate-200 hover:border-blue-200 transition-all cursor-pointer"
              id="refresh-grid-button"
            >
              <RefreshCw className="w-3 h-3" id="refresh-icon" /> Reload Grid
            </button>
          </div>

          {isLoading ? (
            <div className="py-20 text-center bg-white rounded-2xl border border-slate-200 flex flex-col items-center justify-center" id="grid-loader">
              <RefreshCw className="w-8 h-8 text-blue-500 animate-spin mb-4" id="spin-grid" />
              <p className="text-sm text-slate-500 font-medium" id="load-grid-text">Consulting local persistence database...</p>
            </div>
          ) : stocks.length === 0 ? (
            <div className="py-20 text-center bg-white rounded-2xl border border-slate-200" id="grid-empty">
              <p className="text-sm text-slate-500" id="empty-grid-text">No companies currently tracked. Search a ticker above to initiate analysis!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="stock-grid">
              {stocks.map((stock) => (
                <motion.div
                  layoutId={`stock-card-${stock.ticker}`}
                  key={stock.ticker}
                  onClick={() => setSelectedStock(stock)}
                  className="bg-white rounded-2xl border border-slate-200 hover:border-slate-300 shadow-sm hover:shadow-md transition-all duration-300 p-6 flex flex-col justify-between cursor-pointer group hover:-translate-y-1"
                  id={`card-${stock.ticker}`}
                >
                  <div id={`card-header-${stock.ticker}`}>
                    {/* Symbol and Badges */}
                    <div className="flex justify-between items-start gap-2 mb-3" id={`badge-row-${stock.ticker}`}>
                      <div className="flex items-center gap-2" id={`sym-box-${stock.ticker}`}>
                        <span className="px-2.5 py-1 bg-slate-900 text-white font-mono font-bold text-sm rounded-lg" id={`ticker-badge-${stock.ticker}`}>
                          {stock.ticker}
                        </span>
                        <span className={`px-2 py-0.5 border text-[11px] font-bold rounded-full ${getTrendColor(stock.trendTier)}`} id={`trend-badge-${stock.ticker}`}>
                          {getTrendArrow(stock.trendTier)}
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 border text-xs font-bold rounded-full ${getStanceColor(stock.stance)}`} id={`stance-badge-${stock.ticker}`}>
                        {stock.stance}
                      </span>
                    </div>

                    {/* Company Name */}
                    <h4 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1" id={`name-${stock.ticker}`}>
                      {stock.name}
                    </h4>

                    {/* Price & Change */}
                    <div className="flex items-baseline gap-2 mt-1.5 mb-4" id={`price-row-${stock.ticker}`}>
                      <span className="text-2xl font-black text-slate-900" id={`price-text-${stock.ticker}`}>
                        ${stock.price.toFixed(2)}
                      </span>
                      <span className={`text-xs font-bold font-mono px-1.5 py-0.5 rounded ${
                        stock.change.startsWith("+") 
                          ? "text-emerald-700 bg-emerald-50" 
                          : "text-rose-700 bg-rose-50"
                      }`} id={`change-text-${stock.ticker}`}>
                        {stock.change}
                      </span>
                    </div>

                    {/* Brief Summary */}
                    <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed mb-6" id={`summary-${stock.ticker}`}>
                      {stock.summary}
                    </p>
                  </div>

                  {/* Rating / Score footer */}
                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between" id={`card-footer-${stock.ticker}`}>
                    <div>
                      <span className="block text-[10px] uppercase tracking-wider text-slate-400 font-bold" id={`score-lbl-${stock.ticker}`}>Proprietary Score</span>
                      <span className="text-2xl font-black text-slate-900" id={`score-val-${stock.ticker}`}>
                        {stock.score}<span className="text-xs text-slate-400 font-normal">/100</span>
                      </span>
                    </div>

                    {/* Simple Custom Sparkline Score Visualizer */}
                    <div className="flex items-center gap-1.5" id={`sparkline-${stock.ticker}`}>
                      <div className="w-16 bg-slate-100 rounded-full h-2 overflow-hidden" id={`progress-bg-${stock.ticker}`}>
                        <div 
                          className={`h-full rounded-full ${
                            stock.score >= 85 
                              ? "bg-emerald-500" 
                              : stock.score >= 70 
                              ? "bg-blue-500" 
                              : "bg-amber-500"
                          }`}
                          style={{ width: `${stock.score}%` }}
                          id={`progress-fill-${stock.ticker}`}
                        ></div>
                      </div>
                      <span className="text-xs font-mono font-bold text-slate-500" id={`action-lbl-${stock.ticker}`}>View →</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Full Equities Analysis Modal */}
      <AnimatePresence>
        {selectedStock && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 md:p-6" id="modal-overlay">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              layoutId={`stock-card-${selectedStock.ticker}`}
              className="bg-white rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
              id="analysis-modal"
            >
              {/* Modal Sticky Header */}
              <div className="bg-slate-950 text-white p-6 border-b border-slate-800 flex justify-between items-start" id="modal-header">
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-2" id="modal-tag-row">
                    <span className="px-2.5 py-0.5 bg-blue-600 text-white font-mono font-bold text-xs rounded" id="modal-ticker-badge">
                      {selectedStock.ticker}
                    </span>
                    <span className={`px-2 py-0.5 border text-[10px] font-bold rounded-full ${getTrendColor(selectedStock.trendTier)}`} id="modal-trend-badge">
                      {getTrendArrow(selectedStock.trendTier)}
                    </span>
                    <span className={`px-2 py-0.5 border text-[10px] font-bold rounded-full ${getStanceColor(selectedStock.stance)}`} id="modal-stance-badge">
                      {selectedStock.stance}
                    </span>
                  </div>
                  <h3 className="text-2xl font-black tracking-tight" id="modal-company-name">
                    {selectedStock.name}
                  </h3>
                  <div className="flex items-center gap-3 mt-1 text-slate-400 text-sm" id="modal-price-meta">
                    <span className="font-mono text-white text-base font-bold" id="modal-price-val">
                      ${selectedStock.price.toFixed(2)}
                    </span>
                    <span className={`text-xs font-bold font-mono px-1.5 py-0.5 rounded ${
                      selectedStock.change.startsWith("+") ? "text-emerald-400" : "text-rose-400"
                    }`} id="modal-change-val">
                      {selectedStock.change}
                    </span>
                    <span className="text-slate-500" id="modal-sep">|</span>
                    <span className="text-xs" id="modal-updated-at">
                      Last Updated: {new Date(selectedStock.lastUpdated).toLocaleString()}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedStock(null)}
                  className="p-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
                  id="modal-close-button"
                >
                  <X className="w-5 h-5" id="close-icon" />
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="p-6 overflow-y-auto space-y-6 flex-grow bg-slate-50" id="modal-scrollable-content">
                
                {/* Proprietary Index & Target Valuation banner */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="modal-top-dashboard-row">
                  
                  {/* Big Score Radial Display */}
                  <div className="bg-white rounded-xl border border-slate-200 p-5 flex flex-col items-center justify-center text-center" id="radial-score-card">
                    <span className="text-xs uppercase tracking-wider text-slate-400 font-bold mb-3" id="rating-lbl">Trend Score</span>
                    <div className="relative flex items-center justify-center mb-2" id="svg-meter-container">
                      <svg className="w-24 h-24 transform -rotate-90" id="score-meter-svg">
                        <circle cx="48" cy="48" r="40" className="stroke-slate-100" strokeWidth="8" fill="transparent" id="bg-circle" />
                        <circle 
                          cx="48" 
                          cy="48" 
                          r="40" 
                          className={
                            selectedStock.score >= 85 
                              ? "stroke-emerald-500" 
                              : selectedStock.score >= 70 
                              ? "stroke-blue-500" 
                              : "stroke-amber-500"
                          } 
                          strokeWidth="8" 
                          fill="transparent" 
                          strokeDasharray={251.2}
                          strokeDashoffset={251.2 - (251.2 * selectedStock.score) / 100}
                          strokeLinecap="round"
                          id="fill-circle"
                        />
                      </svg>
                      <div className="absolute text-center" id="score-text-overlay">
                        <span className="text-3xl font-black text-slate-900" id="modal-score-num">{selectedStock.score}</span>
                        <span className="block text-[10px] text-slate-400 font-bold" id="max-scale">/100</span>
                      </div>
                    </div>
                    <span className="text-xs text-slate-500 font-semibold" id="stance-verdict">Consensus recommendation</span>
                  </div>

                  {/* Summary Narrative */}
                  <div className="bg-white rounded-xl border border-slate-200 p-5 md:col-span-2 flex flex-col justify-between" id="summary-card">
                    <div id="narrative-top">
                      <span className="text-xs uppercase tracking-wider text-slate-400 font-bold block mb-1.5" id="summary-lbl">Executive Research Summary</span>
                      <p className="text-sm text-slate-700 leading-relaxed font-normal" id="summary-text">
                        {selectedStock.summary}
                      </p>
                    </div>
                    <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-4 mt-3" id="risk-target-row">
                      <div id="target-box">
                        <span className="block text-[10px] uppercase tracking-wider text-slate-400 font-bold" id="target-lbl">12M Consensus Target</span>
                        <span className="text-lg font-extrabold text-slate-900 flex items-center gap-1" id="target-val">
                          <Target className="w-4 h-4 text-blue-600" id="target-icon" /> ${selectedStock.targetPrice.toFixed(2)}
                        </span>
                      </div>
                      <div id="risk-box">
                        <span className="block text-[10px] uppercase tracking-wider text-slate-400 font-bold" id="risk-lbl">System Risk Profile</span>
                        <span className={`inline-block px-2 py-0.5 rounded border text-xs font-bold mt-0.5 ${getRiskColor(selectedStock.riskLevel)}`} id="risk-val">
                          {selectedStock.riskLevel} Risk
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Sub-Metric Score Breakdown */}
                <div className="bg-white rounded-xl border border-slate-200 p-5" id="sub-scores-section">
                  <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2" id="breakdown-title">
                    Valuation &amp; Health Core Breakdown
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="breakdown-grid">
                    {[
                      { key: "valuation", label: "Fundamental Valuation Index", desc: "Measures share price relative to systemic book, sales, & earnings models.", score: selectedStock.breakdown.valuation },
                      { key: "growth", label: "Growth Capital Momentum", desc: "Analyzes quarter-over-quarter revenue, margin expansions, and TAM growth.", score: selectedStock.breakdown.growth },
                      { key: "financialHealth", label: "Balance Sheet Resilience", desc: "Gauges long term debt-to-equity leverage, cash reserves, and solvency.", score: selectedStock.breakdown.financialHealth },
                      { key: "momentum", label: "Price Technical Momentum", desc: "Calculates moving averages convergence, RSI indices, & market trend strength.", score: selectedStock.breakdown.momentum }
                    ].map((m) => (
                      <div key={m.key} className="space-y-1.5" id={`metric-box-${m.key}`}>
                        <div className="flex justify-between items-baseline" id={`metric-lbl-row-${m.key}`}>
                          <span className="text-sm font-bold text-slate-800" id={`metric-lbl-${m.key}`}>{m.label}</span>
                          <span className="text-sm font-bold text-blue-600" id={`metric-val-${m.key}`}>{m.score}/100</span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-normal" id={`metric-desc-${m.key}`}>{m.desc}</p>
                        <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden" id={`progress-bg-${m.key}`}>
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              m.score >= 80 
                                ? "bg-emerald-500" 
                                : m.score >= 60 
                                ? "bg-blue-500" 
                                : "bg-amber-500"
                            }`}
                            style={{ width: `${m.score}%` }}
                            id={`progress-fill-${m.key}`}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Target Price Upside Projection */}
                <div className="bg-white rounded-xl border border-slate-200 p-5" id="upside-projection-section">
                  <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2" id="upside-title">
                    12-Month Target Upside Projection
                  </h4>
                  {(() => {
                    const upsidePercent = ((selectedStock.targetPrice - selectedStock.price) / selectedStock.price) * 100;
                    const isPositive = upsidePercent >= 0;
                    return (
                      <div className="flex flex-col md:flex-row items-center justify-between gap-6" id="upside-block">
                        <div className="space-y-1 text-center md:text-left" id="upside-text">
                          <p className="text-xs text-slate-400 font-bold uppercase tracking-wider" id="projection-lbl">Consensus Upside Stance</p>
                          <p className="text-2xl font-black text-slate-900" id="projection-ratio">
                            ${selectedStock.price.toFixed(2)} <span className="text-slate-300 font-light font-mono text-lg">→</span> ${selectedStock.targetPrice.toFixed(2)}
                          </p>
                          <p className="text-xs text-slate-500" id="projection-disclaimer">Based on the average 12-month analyst target projections.</p>
                        </div>
                        <div className={`px-5 py-4 rounded-xl border text-center font-bold ${
                          isPositive 
                            ? "bg-emerald-50 border-emerald-200 text-emerald-800" 
                            : "bg-rose-50 border-rose-200 text-rose-800"
                        }`} id="upside-badge-container">
                          <span className="block text-xs uppercase tracking-wider opacity-70" id="badge-lbl">Calculated Upside</span>
                          <span className="text-3xl font-black font-mono" id="badge-percent">
                            {isPositive ? "+" : ""}{upsidePercent.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* Strategic Catalysts: Bull & Bear Cases */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="catalysts-row">
                  {/* Bull Case */}
                  <div className="bg-white rounded-xl border border-emerald-100 p-5" id="bull-catalysts-container">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-emerald-800 flex items-center gap-1.5 mb-3 border-b border-emerald-50 pb-2" id="bull-title">
                      <CheckCircle className="w-4 h-4 text-emerald-600" id="bull-icon" /> Bull Thesis &amp; Upward Catalysts
                    </h5>
                    <ul className="space-y-3" id="bull-list">
                      {selectedStock.catalysts.filter(c => c.type === "bull").map((c, idx) => (
                        <li key={idx} className="text-xs text-slate-600 flex items-start gap-2.5 leading-relaxed" id={`bull-item-${idx}`}>
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" id={`bullet-bull-${idx}`}></span>
                          <p id={`text-bull-${idx}`}>{c.text}</p>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Bear Case */}
                  <div className="bg-white rounded-xl border border-rose-100 p-5" id="bear-catalysts-container">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-rose-800 flex items-center gap-1.5 mb-3 border-b border-rose-50 pb-2" id="bear-title">
                      <AlertCircle className="w-4 h-4 text-rose-600" id="bear-icon" /> Bear Risks &amp; Downward Vulnerabilities
                    </h5>
                    <ul className="space-y-3" id="bear-list">
                      {selectedStock.catalysts.filter(c => c.type === "bear").map((c, idx) => (
                        <li key={idx} className="text-xs text-slate-600 flex items-start gap-2.5 leading-relaxed" id={`bear-item-${idx}`}>
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" id={`bullet-bear-${idx}`}></span>
                          <p id={`text-bear-${idx}`}>{c.text}</p>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

              </div>

              {/* Modal Footer */}
              <div className="bg-white border-t border-slate-100 p-4 flex justify-between items-center text-xs text-slate-400 font-semibold" id="modal-footer">
                <span className="flex items-center gap-1" id="footer-grounding-notice">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-500" id="grounding-success-icon" /> Google Search Grounding Enabled
                </span>
                <button
                  onClick={() => setSelectedStock(null)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold transition-all cursor-pointer"
                  id="modal-close-footer-button"
                >
                  Dismiss Analysis
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
