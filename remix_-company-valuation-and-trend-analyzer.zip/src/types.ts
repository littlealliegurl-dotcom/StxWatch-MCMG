export interface StockScoreBreakdown {
  valuation: number;       // 0-100
  growth: number;          // 0-100
  financialHealth: number; // 0-100
  momentum: number;        // 0-100
}

export interface StockCatalyst {
  type: 'bull' | 'bear';
  text: string;
}

export interface CompanyStock {
  ticker: string;
  name: string;
  price: number;
  change: string; // e.g. "+1.42%" or "-0.85%"
  score: number;  // Overall score 0-100
  trendTier: 'Very High' | 'High' | 'Moderate' | 'Low';
  stance: 'Buy' | 'Strong Buy' | 'Hold' | 'Sell';
  riskLevel: 'Low' | 'Medium' | 'High' | 'Speculative';
  targetPrice: number;
  summary: string;
  breakdown: StockScoreBreakdown;
  catalysts: StockCatalyst[];
  lastUpdated: string;
}
